package de.uni_hamburg.informatik.swt.se2.kino.werkzeuge.barzahlung;

import java.awt.event.ActionListener;

import javax.swing.JDialog;

import de.uni_hamburg.informatik.swt.se2.kino.materialien.Vorstellung;

public class BarzahlungsWerkzeug
{
    private BarzahlungsWerkzeugUI _ui;
    
    private int _betrag;
    
    private int _restgeld;
    
    private int _gesamtpreis;
    
    public BarzahlungsWerkzeug(int gesamtpreis)
    {
        _gesamtpreis = gesamtpreis;
        _ui = new BarzahlungsWerkzeugUI(_gesamtpreis);
        registriereUIAktionen();
    }
    
    /**
     * 
     * @require _betrag != null
     * @require _gesamtpreis != null
     */
    private int berechneRestgeld(int betrag)
    {
        return _betrag - _gesamtpreis;
    }
    
    protected JDialog getUIPanel()
    {
        return _ui;
    }
    
    private void registriereUIAktionen()
    {    
        _ui.getOkay().addActionListener((ActionListener) this);
        _ui.getAbbrechen().addActionListener((ActionListener) this);
        _ui.getEingabeBetrag().addActionListener((ActionListener) this);      
    }
    
    private void aktualisiereUIAktionen()
    {
        
    
    }
}

