package de.uni_hamburg.informatik.swt.se2.kino.werkzeuge.kasse;

import java.util.HashSet;
import de.uni_hamburg.informatik.swt.se2.kino.werkzeuge.kasse.Beobachter;

/**
 * Die Objekte dieser abstrakten Klasse werden genutzt um Aenderungen an der UI 
 *  fest zu stellen und diese zu melden, damit das UI auch reagiert.
 *  
 * @author Henrik
 * @version 02.06.17
 */
public abstract class Beobachtbar
{
    //Feldvariablen
    /**
     * @param _beobachter Ein Set gefüllt mit Beobachtern.
     *      Jede GUI-Einheit soll nur einen Beobachter bekommen.
     */
    private HashSet<Beobachter> _beobachter;
    
    //Konstruktor
    /**
     * initialisiert ein Objekt der Klasse Beobachtbar
     * 
     */
    public Beobachtbar()
    {
        _beobachter = new HashSet<Beobachter>();
    }

    //public Methods
    /**
     * setzt einen Beobachter an eine Werkzeug bedeutet ein Beobachter wird in
     * 
     * @require b != null 
     */
    public void setzeBeobachter(Beobachter b)
    {
        assert b != null : "Vorbedingung verletzt: b != null";
        _beobachter.add(b);
    }

    /**
     * meldet, falls Aenderungen an der GUI gemacht wurden und gibt
     *  einen Beobachter an das Kassenwerkzeug weiter. 
     * 
     * @ensure result != null
     */
    protected void meldeAenderungen()
    {
        for(Beobachter b: _beobachter)
        {
            b.beachteAenderungen(this);
        }
    }
}
