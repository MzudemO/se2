package de.uni_hamburg.informatik.swt.se2.kino.werkzeuge.barzahlung;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BarzahlungsWerkzeug
{
    private BarzahlungsWerkzeugUI _ui;

    private int _betrag;

    private int _restgeld;

    private int _gesamtpreis;
    
    private boolean _gezahlt;
    
    public BarzahlungsWerkzeug(int gesamtpreis)
    {
        _gesamtpreis = gesamtpreis;
        _ui = new BarzahlungsWerkzeugUI(_gesamtpreis);
        _ui.macheDialogSichtbar();
        registriereUIAktionen();
    }

    /**
     * 
     * @require _betrag != null
     * @require _gesamtpreis != null
     */
    private int berechneRestgeld()
    {
        _restgeld = _betrag - _gesamtpreis;
        return _restgeld;
    }
    
    public boolean gezahlt()
    {
        return _gezahlt;
    }
    


    private void registriereUIAktionen()
    {
        _ui.getOkay()
            .addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    
                    _gezahlt = true;
                    _ui.schliesseFenster();
                }
            });
        _ui.getAbbrechen()
            .addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    _ui.schliesseFenster();
                }
            });
        _ui.getEingabeBetrag()
            .addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    _betrag = _ui.getBetrag();
                    berechneRestgeld();
                    _ui.getRestbetrag()
                        .setText(Integer.toString(_restgeld));
                    if (_restgeld >= 0)
                    {
                        _ui.getOkay()
                            .setEnabled(true);
                    }
                    else
                    {
                        _ui.getOkay()
                            .setEnabled(false);
                    }
                }
            });
    }

}
