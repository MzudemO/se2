package de.uni_hamburg.informatik.swt.se2.kino.werkzeuge.barzahlung;

import java.awt.FlowLayout;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class BarzahlungsWerkzeugUI
{

    private int _platzpreis;

    public JDialog _frame;

    private JPanel _preisPanel;
    private JLabel _preis;
    private JTextField _anzeigePreis;

    private JPanel _betragPanel;
    private JLabel _betrag;
    private JTextField _eingabeBetrag;

    private JPanel _restbetragPanel;
    private JLabel _restbetrag;
    private JTextField _eingabeRestbetrag;

    private JPanel _buttonPanel;
    private JButton _okay;
    private JButton _abbrechen;

    /**
     * Erzeugt nach und nach das GUI.
     * 
     * @param preis: Preis, der im PlatzVerkaufsWerkzeug errechnet wird
     */

    public BarzahlungsWerkzeugUI(int preis)
    {

        _platzpreis = preis;
        
        // Erzeugt den Frame   
        _frame = erzeugePanel();

        // Zeigt die GUI an
        zeigeGUIan();
        
        }

    /**
     * Zeigt die GUI an
     */
    private void zeigeGUIan()
    {
        _frame.pack();
    }

    /**
     * Erzeugt alle UI Elemente
     */
    private JDialog erzeugePanel()
    {

        JDialog dialog = new JDialog();
//TODO        dialog.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
        dialog.setLayout(
                new BoxLayout(dialog.getContentPane(), BoxLayout.PAGE_AXIS));

        _preisPanel = new JPanel();
        _preisPanel.setLayout(new FlowLayout(FlowLayout.TRAILING));
        _preis = new JLabel();
        _preis.setText("Preis: ");
        _preisPanel.add(_preis);
        
        _anzeigePreis = new JTextField(10);
        _anzeigePreis.setText("" + _platzpreis);
        _anzeigePreis.setEditable(false);
        _preisPanel.add(_anzeigePreis);
        dialog.add(_preisPanel);

        _betragPanel = new JPanel();
        _betragPanel.setLayout(new FlowLayout(FlowLayout.TRAILING));
        _betrag = new JLabel();
        _betrag.setText("Betrag: ");
        _betragPanel.add(_betrag);

        _eingabeBetrag = new JTextField(10);
        _betragPanel.add(_eingabeBetrag);
        dialog.add(_betragPanel);

        _restbetragPanel = new JPanel();
        _restbetragPanel.setLayout(new FlowLayout(FlowLayout.TRAILING));
        _restbetrag = new JLabel();
        _restbetrag.setText("Restbetrag: ");
        _restbetragPanel.add(_restbetrag);

        _eingabeRestbetrag = new JTextField(10);
        _eingabeRestbetrag.setEditable(false);
        _restbetragPanel.add(_eingabeRestbetrag);
        dialog.add(_restbetragPanel);

        _buttonPanel = new JPanel();
        _buttonPanel.setLayout(new FlowLayout(FlowLayout.TRAILING));
        _okay = new JButton("Okay");
        _okay.setEnabled(false);
        _buttonPanel.add(_okay);

        _abbrechen = new JButton("Abbrechen");
        _buttonPanel.add(_abbrechen);
        dialog.add(_buttonPanel);
        
        return dialog;
    }

    /**
     * @return den Frame
     * 
     * @ensure result != null
     */
    public JDialog getFrame()
    {
        return _frame;
    }

    /**
     * @return den Okay-Button
     * 
     * @ensure result != null
     */
    public JButton getOkay()
    {
        return _okay;
    }

    /**
     * @return den Abbrechen-Button
     * 
     * @ensure result != null
     */
    public JButton getAbbrechen()
    {
        return _abbrechen;

    }

    /**
     * @return das Textfeld zur Eingabe des Betrags
     * 
     * @ensure result != null
     */
    public JTextField getEingabeBetrag()
    {
        return _eingabeBetrag;
    }

    /**
     * @return das Textfeld, dass den Restbetrag anzeigt
     * 
     * @ensure result != null
     */
    public JTextField getRestbetrag()
    {
        return _eingabeRestbetrag;
    }

    /**
     * Gibt den eingegebenen Betrag in das TextField _eingabeBetrag als Integer zurück
     * 
     * @return int eingabeBetrag
     */
    public int getBetrag()
    {
        return Integer.parseInt(_eingabeBetrag.getText());
    }

    /**
     * Sorgt dafür, dass der Dialog sichtbar wird. Als extra Methode, da in
     * BarzahlungsWerkzeug aufgerufen werden soll, sonst werden die
     * ActionListener nicht angenommen, solang Fenster geöffnet ist, da modal.
     */
    public void macheDialogSichtbar()
    {
        _frame.setVisible(true);
    }

    /**
     * Schließt den Dialog
     */
    public void schliesseFenster()
    {
        _frame.dispose();
    }

}
