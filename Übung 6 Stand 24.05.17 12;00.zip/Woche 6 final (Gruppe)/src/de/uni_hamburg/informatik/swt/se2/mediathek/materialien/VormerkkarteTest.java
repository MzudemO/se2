package de.uni_hamburg.informatik.swt.se2.mediathek.materialien;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import de.uni_hamburg.informatik.swt.se2.mediathek.fachwerte.Kundennummer;
import de.uni_hamburg.informatik.swt.se2.mediathek.materialien.medien.CD;
import de.uni_hamburg.informatik.swt.se2.mediathek.materialien.medien.Medium;

public class VormerkkarteTest
{
    private Vormerkkarte _karte;
    private Medium _medium;
    private Kunde _kunde;


    public VormerkkarteTest()
    {
        _kunde = new Kunde(new Kundennummer(123456), "ich", "du");
        _medium = new CD("bar", "baz", "foo", 123);

        _karte = new Vormerkkarte(_medium);

    }
    
    @Test
    public void testeKonstruktor()
    {
        assertEquals(_karte.getMedium(), _medium);
    }
    
    @Test
    public void testeAdd()
    {
        _karte.add(_kunde);
        assertEquals(_karte.gibKunden(0),_kunde);
        assertEquals(_karte.gibKunden(1), null);
    }

}
