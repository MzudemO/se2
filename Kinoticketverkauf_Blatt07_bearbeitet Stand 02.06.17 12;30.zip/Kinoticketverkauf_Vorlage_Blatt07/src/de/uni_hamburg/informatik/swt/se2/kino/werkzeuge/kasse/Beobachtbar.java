package de.uni_hamburg.informatik.swt.se2.kino.werkzeuge.kasse;

import java.util.Set;
import de.uni_hamburg.informatik.swt.se2.kino.werkzeuge.kasse.Beobachter;

/**
 * Die Objekte dieser abstrakten Klasse werden genutzt um Aenderungen an der UI 
 *  fest zu stellen und diese zu melden, damit das UI auch reagiert.
 *  
 * @author Henrik
 * @version 02.06.17
 */
public abstract class Beobachtbar
{
    //Feldvariablen
    /**
     * @param _beobachter Ein Set gefüllt mit Beobachtern.
     *      Jede GUI-Einheit soll nur einen Beobachter bekommen.
     */
    //Fehler weil _beobachter bisher nicht benutzt wird.
    private Set<Beobachter> _beobachter;
    
    //Konstruktor
    /**
     * initialisiert ein Objekt der Klasse Beobachtbar
     * 
     */
    public Beobachtbar()
    {
        //Fehler liegt wohl daran dass er Beobachter noch nicht kennt???
        //TODO Fehler beheben: löst sich wahrscheinlich im Laufe der
        //      Impl auf. Finde aktuell keine Lösung
        _beobachter = new Set<Beobachter>();
    }

    //public Methods
    /**
     * setzt einen Beobachter an eine Werkzeug bedeutet ein Beobachter wird in
     * 
     *  
     */
    public void setzeBeobachter()
    {
        //TODO KLassenrumpf implementieren
        _beobachter.add(/*Beobachter B*/);
    }

    /**
     * meldet, falls Aenderungen an der GUI gemacht wurden und gibt
     *  einen Beobachter an das Kassenwerkzeug weiter. 
     * 
     * @ensure result != null
     */
    //TODO public oder private? nicht sicher! Logik erschließt sich mir mit public eher.
    public Beobachter meldeAenderungen()
    {
        //TODO Klassenrumpf implementieren
        return null;
    }
}
