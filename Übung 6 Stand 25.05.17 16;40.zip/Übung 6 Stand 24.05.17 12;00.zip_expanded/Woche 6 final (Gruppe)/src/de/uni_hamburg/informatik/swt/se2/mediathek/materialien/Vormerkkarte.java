package de.uni_hamburg.informatik.swt.se2.mediathek.materialien;

import java.util.ArrayList;

import de.uni_hamburg.informatik.swt.se2.mediathek.materialien.medien.Medium;

//TODO Alle Schnittstellenkommentare der Klasse: erledigt!

public class Vormerkkarte
{
    /**
     * Die Liste in der die 3 Vormerker gespeichert werden.
     * Realisiert als ArrayList
     */
    private ArrayList<Kunde> _liste;

    /**
     * Das Medium, zu dem die Wormerkkarte gehört
     */
    private final Medium _medium;

    /**
     * Konstruktor der Vormerkkarte. Erstellt eine Vormmerkkarte.
     * Diese wird dazu genutzt Vormerker für ein Medium in einer Liste, 
     * die maximal 3 lang ist, zu speichern.
     * @param medium Das Medium der Vormerkkarte
     */
    public Vormerkkarte(Medium medium)
    {
        _liste = new ArrayList<Kunde>(3);
        _medium = medium;

    }

    /**
     * Fügt einen Kunden zur Vormerkliste hinzu.
     * Wird immer hinten angehangen.
     * @param kunde
     */
    public void add(Kunde kunde)
    {
        _liste.add(kunde);
    }

    /**
     * Entfernt den ersten Kunden von der Vormerkliste.
     * Alle hinteren rücken automatisch nach.
     */
    public void remove()
    {
        _liste.remove(0);
    }

    /**
     * Gibt die Länge der Liste als int zurück
     * @return Länge der Liste als int
     */
    public int gibLaenge()
    {
        return _liste.size();
    }

    /**
     * Gibt den Kunden zurück der an Position i der Liste steht.
     * @param i Position in der Liste 0<=i<=3
     * @return den Kunden an Position i
     */
    public Kunde gibKunden(int i)
    {
        Kunde kunde = null;
        if (i < gibLaenge())
        {
            kunde = _liste.get(i);
        }

        return kunde;
    }

    /**
     * Gibt zurück, ob ein Kunde in der Liste enthalten ist. 
     * @param kunde Der Kunde auf den geprüft werden soll.
     * @return true/false ob der Kunde drin ist.
     */
    public boolean enthaelt(Kunde kunde)
    {
        return _liste.contains(kunde);
    }

    /**
     * Gibt das Medium zurück, dem die Vormerkkarte zugeordnet ist.
     * @return Das Medium der Vormerkkarte
     */
    public Medium getMedium()
    {
        return _medium;
    }

}
