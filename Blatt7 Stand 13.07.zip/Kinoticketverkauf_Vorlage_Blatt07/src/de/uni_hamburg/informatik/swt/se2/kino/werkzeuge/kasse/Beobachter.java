package de.uni_hamburg.informatik.swt.se2.kino.werkzeuge.kasse;

//TODO Implementation ins Kassenwerkzeug
/**
 * Dieses Interface dient dazu gemeldte Aenderungen der Objekte von
 *  Beobachtbar an das Kassenwerkzeug weiter zu geben, damit dieses
 *  die UI des Programms aktualisieren kann. 
 *  
 * @author Henrik
 * @version 02.06.17
 */
public interface Beobachter
{
    /**
     * aktualisiert die GUI gemäß den angegebenen Änderungen
     * auf dem Interface
     * 
     * @param b Objekt der Klasse Beobachtbar. Wird dazu genutzt um 
     *      die jeweilige GUI zu finden auf der aktualisiert werden muss.
     *      
     * @require b != null;
     */
    public void beachteAenderungen(Beobachtbar b);
}
