package de.uni_hamburg.informatik.swt.se2.mediathek.materialien;

import java.util.ArrayList;

import de.uni_hamburg.informatik.swt.se2.mediathek.materialien.medien.Medium;

public class Vormerkkarte
{

    private ArrayList<Kunde> _liste;
    private final Medium _medium;

    public Vormerkkarte(Medium medium)
    {
        _liste = new ArrayList<Kunde>(3);
        _medium = medium;

    }

    public void add(Kunde kunde)
    {
        _liste.add(kunde);
    }

    public void remove()
    {
        _liste.remove(0);
    }

    public int gibLaenge()
    {
        return _liste.size();
    }

    public Kunde gibKunden(int i)
	{
	    Kunde kunde = null;
	    if(i < gibLaenge())
	    {
	        kunde = _liste.get(i);
	    }
	    
		return kunde;
	}

    public boolean enthaelt(Kunde kunde)
    {
        return _liste.contains(kunde);
    }

    public Medium getMedium()
    {
        return _medium;
    }

}
